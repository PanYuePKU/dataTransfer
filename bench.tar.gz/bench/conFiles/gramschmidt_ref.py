import m5
from m5.objects import *
import sys
sys.path.append(r"/imec/other/meminhwi/pan78/seat-huawei/configs/common")
from O3_ARM_v7a import *
#from caches import *


system = System()
system.clk_domain = SrcClockDomain()
system.clk_domain.clock = '1GHz'
system.clk_domain.voltage_domain = VoltageDomain()

system.mem_mode = 'timing'
system.mem_ranges = [AddrRange('4GB')]

system.cpu = O3_ARM_v7a_3()
#system.cpu = DerivO3CPU()
system.membus = SystemXBar()

#system.cpu.icache = L1ICache()
#system.cpu.dcache = L1DCache()
system.cpu.icache = O3_ARM_v7a_ICache()
system.cpu.dcache = O3_ARM_v7a_DCache()
system.cpu.icache.cpu_side = system.cpu.icache_port
system.cpu.dcache.cpu_side = system.cpu.dcache_port


#system.cpu.icache.connectCPU(system.cpu)
#system.cpu.dcache.connectCPU(system.cpu)

system.l2bus = L2XBar()
#system.cpu.icache.connectBus(system.l2bus)
#system.cpu.dcache.connectBus(system.l2bus)
system.cpu.icache.mem_side = system.l2bus.slave
system.cpu.dcache.mem_side = system.l2bus.slave

system.l2cache = O3_ARM_v7aL2()
system.l2cache.cpu_side = system.l2bus.master
system.l2cache.mem_side = system.membus.slave

system.cpu.createInterruptController()
#system.cpu.interrupts[0].pio = system.membus.master
#system.cpu.interrupts[0].int_master = system.membus.slave
#system.cpu.interrupts[0].int_slave = system.membus.master

system.system_port = system.membus.slave

#system.mem_ctrl = DDR3_1600_8x8()
system.mem_ctrl = DDR4_2400_4x16()
system.mem_ctrl.range = system.mem_ranges[0]
system.mem_ctrl.port = system.membus.master

process = Process()
#process.cmd = ['tests/test-progs/hello/bin/arm/linux/hello']
process.cmd = ['/imec/other/meminhwi/projectdata/benchmarks/polybench-c-4.2/gramschmidt_ref']

system.cpu.workload = process
system.cpu.createThreads()

root = Root(full_system = False, system = system)
m5.instantiate()

print("Begining simulation!")
exit_event = m5.simulate()

print('Exiting @ tick {} becuse {}'
	.format(m5.curTick(), exit_event.getCause()))
