#!/usr/bin/env python3

import re
import os
import shutil

#bmk_names = ['2mm_ref']
bmk_names = ['3mm_ref','adi_ref','atax_ref','bicg_ref','cholesky_ref','correlation_ref','deriche_ref','doitgen_ref','durbin_ref',\
'fdtd-2d_ref','floyd-warshall_ref','gemm_ref','gemver_ref','gesummv_ref','gramschmidt_ref','heat-3d_ref','jacobi-1d_ref',\
'jacobi-2d_ref','ludcmp_ref','lu_ref','mvt_ref','nussinov_ref','seidel-2d_ref','symm_ref','syr2k_ref',\
'syrk_ref']


l1dSize = '32kB'
l1dReadLat = '2'
l1dWriteLat = '2'

l1iSize = '32kB'
l1iReadLat = '2'
l1iWriteLat = '2'

l2Size = '2MB'
l2ReadLat = '21'
l2WriteLat = '40'

for bmk_name in bmk_names:
	#fin = open('test_arm.py','r')
	#fout = open('conFiles/'+ bmk_name[0] + r'_MRAM.py','w')
        '''
	fout = open('conFiles/'+ bmk_name + r'.py','w')

	for line in fin.readlines():
	
		if re.search(r'XXX',line):
			#print(line.strip())
			line = re.sub(r'XXX',bmk_name,line)
		fout.write(line)

	fin.close()
	fout.close()
	'''

	cmd = '/imec/other/meminhwi/projectdata/benchmarks/polybench-c-4.2/' + bmk_name


	os.system('pwd')
	os.chdir('/imec/other/meminhwi/pan78/ver1d0')
	os.system('pwd')


	#os.system('build/ARM/gem5.opt configs/tutorial/test_arm.py')
	#os.system('build/ARM/gem5.opt configs/tutorial/conFiles/2mm_ref.py')
	#os.system('build/ARM/gem5.opt configs/tutorial/conFiles/' + bmk_name[0] + r'_MRAM.py')
	os.system('build/ARM/gem5.opt configs/pan/15A.py --cmd=' + cmd + ' --l1d-size=' + l1dSize + ' --l1d-read-lat='\
			+ l1dReadLat + ' --l1d-write-pen=' + l1dWriteLat + ' --l1i-size=' + l1iSize + ' --l1i-read-lat='\
			+ l1iReadLat + ' --l1i-write-pen=' + l1iWriteLat + ' --l2-size=' + l2Size + ' --l2-read-lat='\
			+ l2ReadLat + ' --l2-write-pen=' + l2WriteLat)

	os.chdir('/imec/other/meminhwi/pan78/ver1d0/configs/pan/')
	os.system('pwd')
	shutil.copyfile('/imec/other/meminhwi/pan78/ver1d0/m5out/stats.txt','poly/MRAM_w/stats_'+bmk_name+r'.txt')
	shutil.copyfile('/imec/other/meminhwi/pan78/ver1d0/m5out/config.ini','poly/MRAM_w/config_'+bmk_name+r'.txt')
