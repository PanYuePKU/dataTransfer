import m5
# import all of the SimObjects
from m5.objects import *
# Add the common scripts to our path
m5.util.addToPath('../')
# import the cpu config folder we made
m5.util.addToPath('../timon/cpu')
from common import MemConfig
from CortexA15 import *

# import the SimpleOpts module
from common import SimpleOpts

# Set the usage message to display
SimpleOpts.set_usage("usage: %prog [options] <binary to execute>")
# Set options available for this file
SimpleOpts.add_option('--cmd', help = 'Binary to execute')
SimpleOpts.add_option('--options', help = 'String to pass as options to binary')
SimpleOpts.add_option('--ff', help = """Specify the number of instructions to
                      fastforward, if not specified, just starts with detailed
                      model""")
SimpleOpts.add_option('--num-cpus', help = 'Number of cpus in the system')
SimpleOpts.add_option('--l3cache', help = 'Specify the use of an L3 cache')
SimpleOpts.add_option('--mem-type', help = """Select memory type, use NVMainMemory
                      and the --nvmain-config option to select an appropriate
                      nvmain config""")
SimpleOpts.add_option('--nvmain-config', help = """path to nvmain config
                       file""")
SimpleOpts.add_option('--nvmain-StatsFile', help = '''path to StatsFile''')
SimpleOpts.add_option('--nvmain-ConfigLog', help = '''path to ConfigLog''')
SimpleOpts.add_option('--l1i-read-lat', help = 'read latency for l1i')
SimpleOpts.add_option('--l1i-write-pen', help = 'write penalty for l1i')
SimpleOpts.add_option('--l1i-size', help = 'l1i size')
SimpleOpts.add_option('--l2-read-lat', help = 'read latency for l2')
SimpleOpts.add_option('--l2-write-pen', help = 'write penalty  for l2')
SimpleOpts.add_option('--l2-size', help = 'l2 size')
SimpleOpts.add_option('--l1d-read-lat', help = 'read latency for l1d')
SimpleOpts.add_option('--l1d-write-pen', help = 'write penalty for l1d')
SimpleOpts.add_option('--l1d-size', help = 'l1d size')


# Finalize the arguments and grab the opts so we can pass it on to our objects
(opts, args) = SimpleOpts.parse_args()

# get ISA for the default binary to run. This is mostly for simple testing
isa = str(m5.defines.buildEnv['TARGET_ISA']).lower()
if isa != 'arm':
    print 'Warning: this script was meant to be used with an ARM simulation'

# Default to running productomatrices_normal, without options
if not opts or not opts.cmd:
    binary = 'tests_seat/productomatrices/arm/productomatrices_normal'
    binary_options = ''
else:
    binary = opts.cmd
    if opts.options:
        binary_options = opts.options.split()
    else:
        binary_options = ''

if args:
    print "Error: script does not take any positional arguments"
    sys.exit(1)

# create the system we are going to simulate
system = System()
# Set the clock fequency of the system (and all of its children)
system.clk_domain = SrcClockDomain()
#this clock seems appropriate for an A15
system.clk_domain.clock = '2.1GHz'
system.clk_domain.voltage_domain = VoltageDomain()

# 2GB is fine for this system
system.mem_ranges = [AddrRange('2GB')] # Create an address range
# Create a memory bus, a coherent crossbar, in this case
system.l2bus = L2XBar()
# Create an L2 cache and connect it to the l2bus
system.l2cache = CortexA15L2()
if opts.l2_read_lat:
    system.l2cache.tag_latency = int(opts.l2_read_lat)
    system.l2cache.data_latency = int(opts.l2_read_lat)
    system.l2cache.response_latency = int(opts.l2_read_lat)

if opts.l2_write_pen:
    system.l2cache.write_latency = int(opts.l2_write_pen)

if opts.l2_size:
    system.l2cache.size = opts.l2_size
system.l2cache.cpu_side = system.l2bus.master
## Create a memory bus
system.membus = SystemXBar()

# Connect the system up to the membus
system.system_port = system.membus.slave

if opts.mem_type:
    # MemConfig.config_mem(opts, system)
    cls = MemConfig.get(opts.mem_type)
    system.mem_ctrl = cls()
    system.mem_ctrl.range = system.mem_ranges[0]
    system.mem_ctrl.port = system.membus.master
else:
    # Create a LPDDR3 memory controller
    system.mem_ctrl = LPDDR3_1600_1x32()
    system.mem_ctrl.range = system.mem_ranges[0]
    system.mem_ctrl.port = system.membus.master

#optional L3, normally no A15 has an L3 cache but okay
if opts.l3cache:
    system.l3cache = CortexA15L3()
    system.l3cache.size = opts.l3cache
    system.l3cache.cpu_side = system.l2cache.mem_side
    system.l3cache.mem_side = system.membus.slave
    #change some stuff for L2 since that is not LLC anymore
    system.l2cache.clusivity = 'mostly_incl'
    system.l2cache.prefetch_on_access = False
else:
    # Connect the L2 cache to the membus
    system.l2cache.mem_side = system.membus.slave

if opts.num_cpus:
    np = int(opts.num_cpus)
else:
    np = 1

if opts.ff:
    system.mem_mode = 'atomic'
    system.cpu = [AtomicSimpleCPU() for i in xrange(np)]
    for i in xrange(np):
        system.cpu[i].max_insts_any_thread = opts.ff
else:
    system.mem_mode = 'timing'
    system.cpu = [CortexA15() for i in xrange(np)]

for i in xrange(np):
    system.cpu[i].cpu_id = i
    # Create an L1 instruction and data cache
    system.cpu[i].icache = CortexA15_ICache()
    system.cpu[i].dcache = CortexA15_DCache()

    #adjust latencnies if required
    if opts.l1i_read_lat:
        system.cpu[i].icache.tag_latency = int(opts.l1i_read_lat)
        system.cpu[i].icache.data_latency = int(opts.l1i_read_lat)
        system.cpu[i].icache.response_latency = int(opts.l1i_read_lat)
    if opts.l1i_write_pen:
        system.cpu[i].icache.write_latency = int(opts.l1i_write_pen)
    if opts.l1i_size:
        system.cpu[i].icache.size = opts.l1i_size
    if opts.l1d_read_lat:
        system.cpu[i].dcache.tag_latency = int(opts.l1d_read_lat)
        system.cpu[i].dcache.data_latency = int(opts.l1d_read_lat)
        system.cpu[i].dcache.response_latency = int(opts.l1d_read_lat)
    if opts.l1d_write_pen:
        system.cpu[i].dcache.write_latency = int(opts.l1d_write_pen)
    if opts.l1d_size:
        system.cpu[i].dcache.size = opts.l1d_size

    # Connect the instruction and data caches to the CPU
    system.cpu[i].icache.cpu_side = system.cpu[i].icache_port
    system.cpu[i].dcache.cpu_side = system.cpu[i].dcache_port

    # Hook the CPU ports up to the l2bus
    system.cpu[i].icache.mem_side = system.l2bus.slave
    system.cpu[i].dcache.mem_side = system.l2bus.slave

    system.cpu[i].itb.walker.port = system.membus.slave
    system.cpu[i].dtb.walker.port = system.membus.slave
    # create the interrupt controller for the CPU
    system.cpu[i].createInterruptController()

process = Process()
if binary_options:
    process.cmd = [binary] + binary_options
else:
    process.cmd = [binary]

for i in xrange(np):
        # Set the cpu to use the process as its workload and create thread contexts
    system.cpu[i].workload = process
    system.cpu[i].createThreads()

# set up the root SimObject with the simulated system and start the simulation
root = Root(full_system = False)
root.system = system
if opts.ff:
    system.switch_cpu = [CortexA15(switched_out = True, cpu_id =
                                   system.cpu[i].cpu_id, workload =
                                   system.cpu[i].workload) for i in xrange(np)]

    switchCpuList = [(system.cpu[i], system.switch_cpu[i]) for i in xrange(np)]

    m5.instantiate()
    print "Fastforwarding for %i instructions..." % (int(opts.ff))
    exit_event = m5.simulate()
    print """Ended fastforwarding @ tick %i
            because %s""" % (m5.curTick(), exit_event.getCause())
    if exit_event.getCause() == "a thread reached the max instruction count":
        m5.switchCpus(system, switchCpuList)
        m5.stats.reset()
        print """Starting detailed simulation """
        exit_event = m5.simulate()
        print """Ended detailed simulation @tick %i
                because %s""" % (m5.curTick(), exit_event.getCause())

else:
    m5.instantiate()
    print "Beginning simulation!"
    exit_event = m5.simulate()
    print 'Exiting @ tick %i because %s' % (m5.curTick(), exit_event.getCause())
