#!/usr/bin/env python3

import re
import os
import numpy as np
import pandas as pd

list = os.listdir('./')
d = os.path.abspath(__file__)
p = os.path.dirname(d)
dirName = p.split('/')[-1]
print(dirName)

############# pick up some import parameters
paraList = ['sim_ticks','dcache.ReadReq_accesses::total','dcache.ReadReq_misses::total',\
		'dcache.WriteReq_accesses::total','dcache.overall_accesses::total','dcache.overall_miss_rate::total',\
		'dcache.demand_miss_latency::total','icache.ReadReq_accesses::total','icache.overall_miss_rate::total',\
		'icache.demand_miss_latency::total','l2cache.ReadExReq_accesses::total','l2cache.ReadCleanReq_accesses::total',\
		'l2cache.ReadSharedReq_accesses::total',\
		'l2cache.WritebackClean_accesses::total','l2cache.WritebackDirty_accesses::total','l2cache.overall_accesses::total',\
		'l2cache.overall_miss_rate::total','l2cache.demand_miss_latency::total','mem_ctrl.num_reads::total']
fout = open(dirName+'.csv','w')
fout.write('bmk_name,'+','.join(paraList)+"\n")

for filename in list:
	if filename.startswith('stats_'):
		#pass
		#print(filename + "\n")
		fin = open(filename,'r')
		value = ['NaN'] * (len(paraList)+1)
		value[0] = filename.split('.')[0][6:]
		for line in fin.readlines():
			for para in paraList:
				if re.search(para,line):
					#print(line+"\n")
					tmpline = line.split()
					#print(tmpline[1])
					value[paraList.index(para)+1] = str(tmpline[1])
		fout.write(','.join(value)+"\n")
		fin.close()
fout.close()

####### generate some easy for reading columns
df = pd.read_csv(dirName+'.csv',sep=',')
df_new = pd.DataFrame()

df_new['bmk_name'] = df['bmk_name']
df_new['execution time'] = df['sim_ticks']
df_new['L1D reads'] = df['dcache.ReadReq_accesses::total']
df_new['L1D writes'] = df['dcache.ReadReq_misses::total'] + df['dcache.WriteReq_accesses::total']
df_new['L1D total accesses'] = df['dcache.overall_accesses::total']
df_new['L1D miss rate'] = df['dcache.overall_miss_rate::total']
df_new['L1I reads'] = df['icache.ReadReq_accesses::total']
df_new['L1I miss rate'] = df['icache.overall_miss_rate::total']
df_new['L2 reads'] = df['l2cache.ReadExReq_accesses::total'] + df['l2cache.ReadCleanReq_accesses::total']\
			+ df['l2cache.ReadSharedReq_accesses::total']
df_new['L2 writes'] = df['l2cache.WritebackClean_accesses::total'] + df['l2cache.WritebackDirty_accesses::total']
df_new['L2 total accesses'] = df['l2cache.overall_accesses::total']
df_new['L2 miss rate'] = df['l2cache.overall_miss_rate::total']
df_new['main memory accesses'] = df['mem_ctrl.num_reads::total']

#df.reindex(columns=col)
df_new = pd.merge(df_new,df,on='bmk_name')
#print(df_new.loc[:,['L1D writes','dcache.ReadReq_misses::total','dcache.WriteReq_accesses::total']])
df_new.to_csv(dirName+'_final.csv',index=False, sep=',')
